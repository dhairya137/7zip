const AWS = require("aws-sdk");
const docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  const { httpMethod, path } = event;
  let response;

  try {
    switch (httpMethod) {
      case "GET":
        response = await getItem(path);
        break;
      case "POST":
        response = await putItem(event.body);
        break;
      default:
        response = {
          statusCode: 400,
          body: JSON.stringify({ message: "Invalid HTTP method" }),
        };
        break;
    }
  } catch (error) {
    console.error(error);
    response = {
      statusCode: 500,
      body: JSON.stringify({ message: "Internal server error" }),
    };
  }

  return response;
};

async function getItem(path) {
  const id = path.split("/").pop();
  const params = {
    TableName: process.env.DYNAMO_DB_TABLE,
    Key: { id },
  };

  const { Item } = await docClient.get(params).promise();
  return {
    statusCode: 200,
    body: JSON.stringify(Item),
  };
}

async function putItem(body) {
  const item = JSON.parse(body);
  const params = {
    TableName: process.env.DYNAMO_DB_TABLE,
    Item: item,
  };

  await docClient.put(params).promise();
  return {
    statusCode: 200,
    body: JSON.stringify(item),
  };
}
